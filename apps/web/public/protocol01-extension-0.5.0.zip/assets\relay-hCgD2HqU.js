const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/popup.html-BW_QXm9R.js","assets/storage-D0jtF-fq.js","assets/popup-CQFzN3x4.css"])))=>i.map(i=>d[i]);
var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
import { P as PublicKey, D as sha256, p as TransactionInstruction, o as Transaction, B as nacl, z as ml_kem768, y as hkdf, J as utf8ToBytes, K as Keypair, _ as __vitePreload, S as SystemProgram, x as getConnection$1, I as useWalletStore } from "./popup.html-BW_QXm9R.js";
import "./storage-D0jtF-fq.js";
function getConnection() {
  return getConnection$1(useWalletStore.getState().network);
}
const RELAYER_PROGRAM_ID = new PublicKey(
  "2okhzLVr6FEq5jP19KT6VurcSutx2zE4RhkRamrk5WpW"
);
const SEEDS = {
  CONFIG: Buffer.from("relayer_config"),
  NODE: Buffer.from("relayer_node"),
  JOB: Buffer.from("relay_job")
};
var JobStatus = /* @__PURE__ */ ((JobStatus2) => {
  JobStatus2[JobStatus2["Pending"] = 0] = "Pending";
  JobStatus2[JobStatus2["Completed"] = 1] = "Completed";
  JobStatus2[JobStatus2["Expired"] = 2] = "Expired";
  JobStatus2[JobStatus2["Cancelled"] = 3] = "Cancelled";
  return JobStatus2;
})(JobStatus || {});
const HYBRID_RELAY_HKDF_INFO = utf8ToBytes("p01_relay_job_hybrid_v2");
const KEM_PUBLIC_KEY_SIZE = 1184;
const KEM_CIPHERTEXT_SIZE = 1088;
function encryptForRelayer(payload, relayerEncryptionKey, relayerKemKey) {
  const ephemeral = nacl.box.keyPair();
  const classicSecret = nacl.scalarMult(ephemeral.secretKey, relayerEncryptionKey);
  let symmetricKey;
  let kemCiphertext;
  if (relayerKemKey && relayerKemKey.length === KEM_PUBLIC_KEY_SIZE) {
    const kem = ml_kem768.encapsulate(relayerKemKey);
    kemCiphertext = kem.cipherText;
    const combined = new Uint8Array(classicSecret.length + kem.sharedSecret.length);
    combined.set(classicSecret);
    combined.set(kem.sharedSecret, classicSecret.length);
    symmetricKey = hkdf(sha256, combined, void 0, HYBRID_RELAY_HKDF_INFO, 32);
  } else {
    symmetricKey = hkdf(sha256, classicSecret, void 0, utf8ToBytes("p01_relay_job_v1"), 32);
  }
  const nonce = nacl.randomBytes(nacl.secretbox.nonceLength);
  const ciphertext = nacl.secretbox(payload, nonce, symmetricKey);
  if (kemCiphertext) {
    const result2 = new Uint8Array(1 + 32 + KEM_CIPHERTEXT_SIZE + nonce.length + ciphertext.length);
    result2[0] = 2;
    result2.set(ephemeral.publicKey, 1);
    result2.set(kemCiphertext, 33);
    result2.set(nonce, 33 + KEM_CIPHERTEXT_SIZE);
    result2.set(ciphertext, 33 + KEM_CIPHERTEXT_SIZE + nonce.length);
    return result2;
  }
  const result = new Uint8Array(1 + 32 + nonce.length + ciphertext.length);
  result[0] = 1;
  result.set(ephemeral.publicKey, 1);
  result.set(nonce, 33);
  result.set(ciphertext, 33 + nonce.length);
  return result;
}
async function fetchRelayerConfig(connection) {
  const [configPDA] = PublicKey.findProgramAddressSync(
    [SEEDS.CONFIG],
    RELAYER_PROGRAM_ID
  );
  const info = await connection.getAccountInfo(configPDA);
  if (!info) throw new Error("Relayer config not initialized");
  const data = info.data;
  let offset = 8;
  const authority = new PublicKey(data.slice(offset, offset + 32));
  offset += 32;
  const minStake = data.readBigUInt64LE(offset);
  offset += 8;
  data.readUInt16LE(offset);
  offset += 2;
  const jobFeeLamports = data.readBigUInt64LE(offset);
  offset += 8;
  const protocolFeeBps = data.readUInt16LE(offset);
  offset += 2;
  new PublicKey(data.slice(offset, offset + 32));
  offset += 32;
  const jobTimeoutSlots = data.readBigUInt64LE(offset);
  offset += 8;
  data.readBigUInt64LE(offset);
  offset += 8;
  data.readBigUInt64LE(offset);
  offset += 8;
  const activeRelayerCount = data.readUInt16LE(offset);
  offset += 2;
  data.readBigUInt64LE(offset);
  offset += 8;
  const isActive = data[offset] === 1;
  return {
    authority,
    minStake,
    jobFeeLamports,
    protocolFeeBps,
    jobTimeoutSlots,
    activeRelayerCount,
    isActive
  };
}
async function fetchActiveRelayers(connection) {
  const discriminator = sha256(Buffer.from("account:RelayerNode")).slice(0, 8);
  const IS_ACTIVE_OFFSET = 120;
  const accounts = await connection.getProgramAccounts(RELAYER_PROGRAM_ID, {
    filters: [
      { memcmp: { offset: 0, bytes: Buffer.from(discriminator).toString("base64"), encoding: "base64" } },
      { memcmp: { offset: IS_ACTIVE_OFFSET, bytes: Buffer.from([1]).toString("base64"), encoding: "base64" } }
    ]
  });
  return accounts.map(({ pubkey, account }) => {
    const data = account.data;
    let offset = 8;
    const operator = new PublicKey(data.slice(offset, offset + 32));
    offset += 32;
    const encryptionKey = new Uint8Array(data.slice(offset, offset + 32));
    offset += 32;
    const stake = Number(data.readBigUInt64LE(offset));
    offset += 8;
    Number(data.readBigUInt64LE(offset));
    offset += 8;
    Number(data.readBigUInt64LE(offset));
    offset += 8;
    const lastActiveSlot = Number(data.readBigUInt64LE(offset));
    offset += 8;
    const registeredAtSlot = Number(data.readBigUInt64LE(offset));
    offset += 8;
    offset += 8;
    const isActive = data[offset] === 1;
    offset += 1;
    const reputationScore = data.readUInt32LE(offset);
    offset += 4;
    offset += 32;
    let kemEncryptionKey;
    if (offset + 1 + KEM_PUBLIC_KEY_SIZE <= data.length) {
      const hasKemKey = data[offset] === 1;
      offset += 1;
      if (hasKemKey) {
        kemEncryptionKey = new Uint8Array(data.slice(offset, offset + KEM_PUBLIC_KEY_SIZE));
      }
    }
    return {
      address: pubkey,
      operator,
      encryptionKey,
      kemEncryptionKey,
      stake,
      isActive,
      reputationScore,
      lastActiveSlot,
      registeredAtSlot
    };
  });
}
function selectRelayer(relayers, blockhash, jobId, excludedOperators) {
  let candidates = relayers;
  if (excludedOperators && excludedOperators.size > 0) {
    candidates = relayers.filter((r) => !excludedOperators.has(r.operator.toBase58()));
    if (candidates.length === 0) {
      throw new Error(`All ${relayers.length} active relayers excluded — no candidate remaining`);
    }
  }
  if (candidates.length === 0) throw new Error("No active relayers");
  if (candidates.length === 1) {
    const idx = relayers.indexOf(candidates[0]);
    return { index: idx, relayer: candidates[0] };
  }
  const input = new Uint8Array(blockhash.length + jobId.length);
  input.set(Buffer.from(blockhash), 0);
  input.set(jobId, blockhash.length);
  const hash = sha256(input);
  const seed = (hash[0] | hash[1] << 8 | hash[2] << 16 | (hash[3] & 127) << 24) >>> 0;
  const candidateIdx = seed % candidates.length;
  const selected = candidates[candidateIdx];
  const indexInOriginal = relayers.indexOf(selected);
  return { index: indexInOriginal, relayer: selected };
}
const LIVENESS_THRESHOLD_SLOTS = 5e4;
function filterByLiveness(relayers, currentSlot) {
  return relayers.filter((r) => {
    if (r.lastActiveSlot === 0) {
      return currentSlot - r.registeredAtSlot < LIVENESS_THRESHOLD_SLOTS;
    }
    return currentSlot - r.lastActiveSlot < LIVENESS_THRESHOLD_SLOTS;
  });
}
function generateJobId() {
  return sha256(Keypair.generate().publicKey.toBytes());
}
async function submitRelayJob(serializedTx, walletPublicKey, signTransaction, opts = {}) {
  var _a;
  const connection = getConnection();
  const t0 = Date.now();
  console.log("[Relay] step1/7: fetching config + active relayers");
  const [config, relayers] = await Promise.all([
    fetchRelayerConfig(connection),
    fetchActiveRelayers(connection)
  ]);
  if (!config.isActive) throw new Error("Relay protocol is paused");
  if (relayers.length === 0) throw new Error("No active relayers available");
  console.log("[Relay] step1/7 done: " + relayers.length + " active relayers, jobFee=" + config.jobFeeLamports.toString() + " lamports");
  const filterDormant = opts.filterDormant !== false;
  let candidatePool = relayers;
  if (filterDormant) {
    const currentSlot = await connection.getSlot("confirmed");
    const live = filterByLiveness(relayers, currentSlot);
    if (live.length > 0) {
      candidatePool = live;
      if (live.length < relayers.length) {
        console.log("[Relay] liveness filter: " + live.length + "/" + relayers.length + " active relayers passed");
      }
    } else {
      console.warn("[Relay] liveness filter: 0/" + relayers.length + " relayers look alive — falling back to full set");
    }
  }
  console.log("[Relay] step2/7: selecting relayer deterministically" + (((_a = opts.excludedOperators) == null ? void 0 : _a.size) ? " (excluded=" + opts.excludedOperators.size + ")" : ""));
  const jobId = generateJobId();
  const { blockhash: currentBlockhash } = await connection.getLatestBlockhash("confirmed");
  const { relayer: selectedRelayer } = selectRelayer(candidatePool, currentBlockhash, jobId, opts.excludedOperators);
  console.log("[Relay] step2/7 done: relayer=" + selectedRelayer.operator.toBase58().slice(0, 8) + "... (kem=" + (selectedRelayer.kemEncryptionKey ? "yes" : "no") + ")");
  const kemKey = opts.forceV1Encryption ? void 0 : selectedRelayer.kemEncryptionKey;
  const encrypted = encryptForRelayer(serializedTx, selectedRelayer.encryptionKey, kemKey);
  const encVer = kemKey ? "v2-hybrid" : "v1-x25519";
  console.log("[Relay] step3/7: encrypted innerTx, version=" + encVer + ", ciphertext=" + encrypted.length + "B (cap 1280)");
  const { deriveEphemeralForRelay, addPendingRelay, jobIdToHex } = await __vitePreload(async () => {
    const { deriveEphemeralForRelay: deriveEphemeralForRelay2, addPendingRelay: addPendingRelay2, jobIdToHex: jobIdToHex2 } = await import("./popup.html-BW_QXm9R.js").then((n) => n.C);
    return { deriveEphemeralForRelay: deriveEphemeralForRelay2, addPendingRelay: addPendingRelay2, jobIdToHex: jobIdToHex2 };
  }, true ? __vite__mapDeps([0,1,2]) : void 0);
  const ephemeral = opts.ephemeralKeypair ?? await deriveEphemeralForRelay(jobId);
  const ephemeralSrc = opts.ephemeralKeypair ? "caller-provided" : "derived";
  console.log("[Relay] step4/7: ephemeral=" + ephemeral.publicKey.toBase58().slice(0, 8) + "... (" + ephemeralSrc + ")");
  const RELAY_JOB_LEN = 1414;
  const jobRent = await connection.getMinimumBalanceForRentExemption(RELAY_JOB_LEN);
  const txFees = 5e4;
  const ephemeralRentMin = await connection.getMinimumBalanceForRentExemption(0);
  const fundAmount = Number(config.jobFeeLamports) + jobRent + txFees + ephemeralRentMin;
  const jobIdHex = jobIdToHex(jobId);
  await addPendingRelay({
    jobId: jobIdHex,
    ephemeralPubkey: ephemeral.publicKey.toBase58(),
    expectedLamports: fundAmount,
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  });
  console.log("[Relay] step5/7: pre-funding ephemeral, total=" + fundAmount + " lamports (jobFee+rent+txFees)");
  const fundTx = new Transaction().add(
    SystemProgram.transfer({
      fromPubkey: walletPublicKey,
      toPubkey: ephemeral.publicKey,
      lamports: fundAmount
    })
  );
  fundTx.feePayer = walletPublicKey;
  const { blockhash: fundBlockhash, lastValidBlockHeight: fundHeight } = await connection.getLatestBlockhash("confirmed");
  fundTx.recentBlockhash = fundBlockhash;
  const signedFundTx = await signTransaction(fundTx);
  const fundSig = await connection.sendRawTransaction(signedFundTx.serialize(), {
    skipPreflight: false,
    preflightCommitment: "confirmed"
  });
  await connection.confirmTransaction(
    { signature: fundSig, blockhash: fundBlockhash, lastValidBlockHeight: fundHeight },
    "confirmed"
  );
  console.log("[Relay] step5/7 done: ephemeral funded with " + fundAmount + " lamports, fundTx=" + fundSig.slice(0, 12) + "...");
  console.log("[Relay] step6/7: building submit_job ix");
  const [configPDA] = PublicKey.findProgramAddressSync([SEEDS.CONFIG], RELAYER_PROGRAM_ID);
  const [relayerNodePDA] = PublicKey.findProgramAddressSync(
    [SEEDS.NODE, selectedRelayer.operator.toBytes()],
    RELAYER_PROGRAM_ID
  );
  const [jobPDA] = PublicKey.findProgramAddressSync(
    [SEEDS.JOB, jobId],
    RELAYER_PROGRAM_ID
  );
  console.log("[Relay] step6/7: jobPDA=" + jobPDA.toBase58().slice(0, 8) + "...");
  const submitDiscriminator = sha256(Buffer.from("global:submit_job")).slice(0, 8);
  const jobIdBuf = Buffer.from(jobId);
  const encLenBuf = Buffer.alloc(4);
  encLenBuf.writeUInt32LE(encrypted.length, 0);
  const data = Buffer.concat([
    Buffer.from(submitDiscriminator),
    jobIdBuf,
    encLenBuf,
    Buffer.from(encrypted)
  ]);
  const submitIx = new TransactionInstruction({
    programId: RELAYER_PROGRAM_ID,
    keys: [
      { pubkey: ephemeral.publicKey, isSigner: true, isWritable: true },
      // submitter
      { pubkey: configPDA, isSigner: false, isWritable: true },
      // config
      { pubkey: relayerNodePDA, isSigner: false, isWritable: true },
      // relayer_node (mut: apply_decay)
      { pubkey: jobPDA, isSigner: false, isWritable: true },
      // relay_job (init)
      { pubkey: SystemProgram.programId, isSigner: false, isWritable: false }
    ],
    data
  });
  const submitTx = new Transaction().add(submitIx);
  submitTx.feePayer = ephemeral.publicKey;
  const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash("confirmed");
  submitTx.recentBlockhash = blockhash;
  submitTx.sign(ephemeral);
  const signature = await connection.sendRawTransaction(submitTx.serialize(), {
    skipPreflight: false,
    preflightCommitment: "confirmed"
  });
  await connection.confirmTransaction(
    { signature, blockhash, lastValidBlockHeight },
    "confirmed"
  );
  console.log("[Relay] step7/7 done: relay-job submitted, outerSig=" + signature.slice(0, 12) + "..., total elapsed=" + (Date.now() - t0) + "ms");
  return {
    jobAddress: jobPDA,
    jobId,
    ephemeralKeypair: ephemeral,
    signature,
    selectedOperator: selectedRelayer.operator
  };
}
const MAX_CHUNK_DATA_SIZE = 900;
const ONCHAIN_MAX_CHUNK_DATA_SIZE = 990;
const RELAY_CHUNK_LEN = 8 + 32 + 2 + 4 + ONCHAIN_MAX_CHUNK_DATA_SIZE + 1;
const SUBMIT_JOB_CHUNKED_DISC = Buffer.from([192, 160, 6, 61, 217, 212, 36, 196]);
const SUBMIT_CHUNK_DISC = Buffer.from([53, 145, 90, 120, 188, 31, 143, 10]);
const SEED_RELAY_CHUNK = Buffer.from("relay_chunk");
function deriveChunkPDA(jobId, chunkIndex) {
  const idxBuf = Buffer.alloc(2);
  idxBuf.writeUInt16LE(chunkIndex, 0);
  const [pda] = PublicKey.findProgramAddressSync(
    [SEED_RELAY_CHUNK, jobId, idxBuf],
    RELAYER_PROGRAM_ID
  );
  return pda;
}
async function submitChunkedRelayJob(serializedTx, walletPublicKey, signTransaction, opts = {}) {
  const connection = getConnection();
  const t0 = Date.now();
  console.log("[ChunkedRelay] step1/7: fetching config + active relayers");
  const [config, relayers] = await Promise.all([
    fetchRelayerConfig(connection),
    fetchActiveRelayers(connection)
  ]);
  if (!config.isActive) throw new Error("Relay protocol is paused");
  if (relayers.length === 0) throw new Error("No active relayers available");
  const filterDormant = opts.filterDormant !== false;
  let candidatePool = relayers;
  if (filterDormant) {
    const currentSlot = await connection.getSlot("confirmed");
    const live = filterByLiveness(relayers, currentSlot);
    if (live.length > 0) candidatePool = live;
  }
  const jobId = generateJobId();
  const { blockhash: outerBlockhash } = await connection.getLatestBlockhash("confirmed");
  const { relayer: selectedRelayer } = selectRelayer(candidatePool, outerBlockhash, jobId, opts.excludedOperators);
  console.log("[ChunkedRelay] step2/7: relayer=" + selectedRelayer.operator.toBase58().slice(0, 8) + "... (kem=" + (selectedRelayer.kemEncryptionKey ? "yes" : "no") + ")");
  const kemKey = opts.forceV1Encryption ? void 0 : selectedRelayer.kemEncryptionKey;
  const encrypted = encryptForRelayer(serializedTx, selectedRelayer.encryptionKey, kemKey);
  const encVer = kemKey ? 2 : 1;
  const totalChunks = Math.ceil(encrypted.length / MAX_CHUNK_DATA_SIZE);
  if (totalChunks < 1 || totalChunks > 256) {
    throw new Error(`Chunked submission requires 1..=256 chunks, got ${totalChunks}`);
  }
  console.log("[ChunkedRelay] step3/7: encrypted=" + encrypted.length + "B → " + totalChunks + " chunks (v" + encVer + ")");
  const { deriveEphemeralForRelay, addPendingRelay, jobIdToHex } = await __vitePreload(async () => {
    const { deriveEphemeralForRelay: deriveEphemeralForRelay2, addPendingRelay: addPendingRelay2, jobIdToHex: jobIdToHex2 } = await import("./popup.html-BW_QXm9R.js").then((n) => n.C);
    return { deriveEphemeralForRelay: deriveEphemeralForRelay2, addPendingRelay: addPendingRelay2, jobIdToHex: jobIdToHex2 };
  }, true ? __vite__mapDeps([0,1,2]) : void 0);
  const ephemeral = opts.ephemeralKeypair ?? await deriveEphemeralForRelay(jobId);
  const RELAY_JOB_LEN = 1414;
  const jobRent = await connection.getMinimumBalanceForRentExemption(RELAY_JOB_LEN);
  const chunkRent = await connection.getMinimumBalanceForRentExemption(RELAY_CHUNK_LEN);
  const ephemeralRentMin = await connection.getMinimumBalanceForRentExemption(0);
  const txFees = 3e4 * (totalChunks + 1);
  const fundAmount = Number(config.jobFeeLamports) + jobRent + totalChunks * chunkRent + txFees + ephemeralRentMin;
  const jobIdHex = jobIdToHex(jobId);
  await addPendingRelay({
    jobId: jobIdHex,
    ephemeralPubkey: ephemeral.publicKey.toBase58(),
    expectedLamports: fundAmount,
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  });
  const sourceBal = await connection.getBalance(walletPublicKey);
  console.log(
    `[ChunkedRelay] step5/7: pre-funding ephemeral=${ephemeral.publicKey.toBase58().slice(0, 8)}… fundAmount=${(fundAmount / 1e9).toFixed(6)} SOL (jobFee=${(Number(config.jobFeeLamports) / 1e9).toFixed(6)} jobRent=${(jobRent / 1e9).toFixed(6)} ${totalChunks}×chunkRent=${(totalChunks * chunkRent / 1e9).toFixed(6)} txFees=${(txFees / 1e9).toFixed(6)} ephRent=${(ephemeralRentMin / 1e9).toFixed(6)})`
  );
  console.log(`[ChunkedRelay] step5/7 source ${walletPublicKey.toBase58().slice(0, 8)}… bal=${(sourceBal / 1e9).toFixed(6)} SOL`);
  if (sourceBal < fundAmount) {
    console.error(`[ChunkedRelay] step5/7 INSUFFICIENT SOURCE BAL — short ${((fundAmount - sourceBal) / 1e9).toFixed(6)} SOL (this will fail simulation)`);
  }
  const fundTx = new Transaction().add(
    SystemProgram.transfer({
      fromPubkey: walletPublicKey,
      toPubkey: ephemeral.publicKey,
      lamports: fundAmount
    })
  );
  fundTx.feePayer = walletPublicKey;
  const { blockhash: fundBlockhash, lastValidBlockHeight: fundHeight } = await connection.getLatestBlockhash("confirmed");
  fundTx.recentBlockhash = fundBlockhash;
  const signedFundTx = await signTransaction(fundTx);
  const fundSig = await connection.sendRawTransaction(signedFundTx.serialize(), {
    skipPreflight: false,
    preflightCommitment: "confirmed"
  });
  await connection.confirmTransaction(
    { signature: fundSig, blockhash: fundBlockhash, lastValidBlockHeight: fundHeight },
    "confirmed"
  );
  console.log(`[ChunkedRelay] step5/7 fund confirmed sig=${fundSig.slice(0, 16)}…`);
  const [configPDA] = PublicKey.findProgramAddressSync([SEEDS.CONFIG], RELAYER_PROGRAM_ID);
  const [relayerNodePDA] = PublicKey.findProgramAddressSync(
    [SEEDS.NODE, selectedRelayer.operator.toBytes()],
    RELAYER_PROGRAM_ID
  );
  const [jobPDA] = PublicKey.findProgramAddressSync([SEEDS.JOB, jobId], RELAYER_PROGRAM_ID);
  const initData = Buffer.alloc(8 + 32 + 2 + 1);
  SUBMIT_JOB_CHUNKED_DISC.copy(initData, 0);
  Buffer.from(jobId).copy(initData, 8);
  initData.writeUInt16LE(totalChunks, 40);
  initData.writeUInt8(encVer, 42);
  const initIx = new TransactionInstruction({
    programId: RELAYER_PROGRAM_ID,
    keys: [
      { pubkey: ephemeral.publicKey, isSigner: true, isWritable: true },
      { pubkey: configPDA, isSigner: false, isWritable: true },
      { pubkey: relayerNodePDA, isSigner: false, isWritable: true },
      { pubkey: jobPDA, isSigner: false, isWritable: true },
      { pubkey: SystemProgram.programId, isSigner: false, isWritable: false }
    ],
    data: initData
  });
  const initTx = new Transaction().add(initIx);
  initTx.feePayer = ephemeral.publicKey;
  const { blockhash: initBh, lastValidBlockHeight: initLvbh } = await connection.getLatestBlockhash("confirmed");
  initTx.recentBlockhash = initBh;
  initTx.sign(ephemeral);
  const initSig = await connection.sendRawTransaction(initTx.serialize(), {
    skipPreflight: false,
    preflightCommitment: "confirmed"
  });
  await connection.confirmTransaction(
    { signature: initSig, blockhash: initBh, lastValidBlockHeight: initLvbh },
    "confirmed"
  );
  const ephBalAfterInit = await connection.getBalance(ephemeral.publicKey);
  console.log(
    `[ChunkedRelay] step6/7: submit_job_chunked ok sig=${initSig.slice(0, 16)}… eph bal=${(ephBalAfterInit / 1e9).toFixed(6)} SOL`
  );
  console.log("[ChunkedRelay] step7/7: submitting " + totalChunks + " chunks");
  const { blockhash: chunkBh, lastValidBlockHeight: chunkLvbh } = await connection.getLatestBlockhash("confirmed");
  const chunkTxs = [];
  for (let i = 0; i < totalChunks; i++) {
    const start = i * MAX_CHUNK_DATA_SIZE;
    const end = Math.min(start + MAX_CHUNK_DATA_SIZE, encrypted.length);
    const data = encrypted.slice(start, end);
    const chunkPda = deriveChunkPDA(jobId, i);
    const ixData = Buffer.alloc(8 + 32 + 2 + 4 + data.length);
    SUBMIT_CHUNK_DISC.copy(ixData, 0);
    Buffer.from(jobId).copy(ixData, 8);
    ixData.writeUInt16LE(i, 40);
    ixData.writeUInt32LE(data.length, 42);
    Buffer.from(data).copy(ixData, 46);
    const ix = new TransactionInstruction({
      programId: RELAYER_PROGRAM_ID,
      keys: [
        { pubkey: ephemeral.publicKey, isSigner: true, isWritable: true },
        { pubkey: jobPDA, isSigner: false, isWritable: true },
        { pubkey: chunkPda, isSigner: false, isWritable: true },
        { pubkey: SystemProgram.programId, isSigner: false, isWritable: false }
      ],
      data: ixData
    });
    const tx = new Transaction().add(ix);
    tx.feePayer = ephemeral.publicKey;
    tx.recentBlockhash = chunkBh;
    tx.sign(ephemeral);
    chunkTxs.push(tx);
  }
  const WAVE_SIZE = 8;
  const chunkSigs = [];
  for (let w = 0; w < chunkTxs.length; w += WAVE_SIZE) {
    const slice = chunkTxs.slice(w, Math.min(w + WAVE_SIZE, chunkTxs.length));
    const sigs = await Promise.all(
      slice.map(
        (tx) => connection.sendRawTransaction(tx.serialize(), {
          skipPreflight: false,
          preflightCommitment: "confirmed"
        })
      )
    );
    chunkSigs.push(...sigs);
    console.log(`[ChunkedRelay] step7 wave ${Math.floor(w / WAVE_SIZE) + 1}: sent ${slice.length} chunks (${chunkSigs.length}/${totalChunks})`);
  }
  await Promise.all(
    chunkSigs.map(
      (sig) => connection.confirmTransaction(
        { signature: sig, blockhash: chunkBh, lastValidBlockHeight: chunkLvbh },
        "confirmed"
      )
    )
  );
  const ephBalFinal = await connection.getBalance(ephemeral.publicKey);
  console.log(
    `[ChunkedRelay] DONE in ${Date.now() - t0}ms — ${totalChunks} chunks landed, jobPDA=${jobPDA.toBase58().slice(0, 8)}… eph leftover=${(ephBalFinal / 1e9).toFixed(6)} SOL`
  );
  return {
    jobAddress: jobPDA,
    jobId,
    ephemeralKeypair: ephemeral,
    signature: initSig,
    selectedOperator: selectedRelayer.operator
  };
}
async function cancelRelayJob(jobAddress, ephemeral) {
  const connection = getConnection();
  const cancelDiscriminator = sha256(Buffer.from("global:cancel_job")).slice(0, 8);
  const cancelIx = new TransactionInstruction({
    programId: RELAYER_PROGRAM_ID,
    keys: [
      { pubkey: ephemeral.publicKey, isSigner: true, isWritable: true },
      // submitter
      { pubkey: jobAddress, isSigner: false, isWritable: true }
      // job (close=submitter)
    ],
    data: Buffer.from(cancelDiscriminator)
  });
  const tx = new Transaction().add(cancelIx);
  tx.feePayer = ephemeral.publicKey;
  const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash("confirmed");
  tx.recentBlockhash = blockhash;
  tx.sign(ephemeral);
  const sig = await connection.sendRawTransaction(tx.serialize(), {
    skipPreflight: false,
    preflightCommitment: "confirmed"
  });
  await connection.confirmTransaction(
    { signature: sig, blockhash, lastValidBlockHeight },
    "confirmed"
  );
  console.log("[Relay] cancel_job done, sig=" + sig.slice(0, 12) + "...");
  return sig;
}
const POLL_INTERVAL_MS = 2e3;
const DEFAULT_TIMEOUT_MS = 12e4;
const BLOCKHASH_CHECK_INTERVAL_MS = 1e4;
const BLOCKHASH_FAILSAFE_MS = 9e4;
class InnerBlockhashExpiredError extends Error {
  constructor(jobAddress) {
    super(
      `Inner-tx blockhash expired while job ${jobAddress.toBase58().slice(0, 8)}... still Pending — abort and retry`
    );
    __publicField(this, "failedOperator");
    this.jobAddress = jobAddress;
    this.name = "InnerBlockhashExpiredError";
  }
}
async function monitorJob(jobAddress, timeoutMs = DEFAULT_TIMEOUT_MS, innerBlockhash) {
  const connection = getConnection();
  const startTime = Date.now();
  let pollCount = 0;
  let lastBlockhashCheck = startTime;
  console.log("[Relay] monitor: starting poll, timeoutMs=" + timeoutMs + (innerBlockhash ? ", blockhash-aware" : ""));
  while (Date.now() - startTime < timeoutMs) {
    const accountInfo = await connection.getAccountInfo(jobAddress);
    pollCount++;
    if (!accountInfo) {
      console.log("[Relay] monitor: account closed → completed (polls=" + pollCount + ", elapsed=" + (Date.now() - startTime) + "ms)");
      return {
        success: true,
        status: 1
        /* Completed */
      };
    }
    const statusByte = accountInfo.data[accountInfo.data.length - 2];
    if (statusByte !== 0) {
      const statusNames = ["Pending", "Completed", "Expired", "Cancelled"];
      console.log("[Relay] monitor: status changed → " + statusNames[statusByte] + " (polls=" + pollCount + ", elapsed=" + (Date.now() - startTime) + "ms)");
      return {
        success: statusByte === 1,
        status: statusByte
      };
    }
    const elapsed = Date.now() - startTime;
    if (innerBlockhash && elapsed - (lastBlockhashCheck - startTime) >= BLOCKHASH_CHECK_INTERVAL_MS) {
      lastBlockhashCheck = Date.now();
      try {
        const isValid = await connection.isBlockhashValid(innerBlockhash, { commitment: "confirmed" });
        if (!isValid) {
          console.warn("[Relay] monitor: inner blockhash expired (job still Pending after " + elapsed + "ms) — fail-fast");
          throw new InnerBlockhashExpiredError(jobAddress);
        }
      } catch (e) {
        if (e instanceof InnerBlockhashExpiredError) throw e;
        console.warn("[Relay] monitor: blockhash probe RPC error, continuing: " + e.message);
      }
    }
    if (innerBlockhash && elapsed >= BLOCKHASH_FAILSAFE_MS) {
      console.warn("[Relay] monitor: blockhash fail-safe triggered after " + elapsed + "ms — assuming expired");
      throw new InnerBlockhashExpiredError(jobAddress);
    }
    if (pollCount % 5 === 0) {
      console.log("[Relay] monitor: still pending, poll=" + pollCount + ", elapsed=" + elapsed + "ms");
    }
    await new Promise((r) => setTimeout(r, POLL_INTERVAL_MS));
  }
  console.log("[Relay] monitor: TIMEOUT after " + timeoutMs + "ms (polls=" + pollCount + ")");
  return {
    success: false,
    status: 0
    /* Pending */
  };
}
async function relayTransaction(serializedTx, walletPublicKey, signTransaction, opts = {}) {
  const { timeoutMs = DEFAULT_TIMEOUT_MS, innerBlockhash, ...submitOpts } = opts;
  const { removePendingRelay, markPendingRelayErrored, jobIdToHex } = await __vitePreload(async () => {
    const { removePendingRelay: removePendingRelay2, markPendingRelayErrored: markPendingRelayErrored2, jobIdToHex: jobIdToHex2 } = await import("./popup.html-BW_QXm9R.js").then((n) => n.C);
    return { removePendingRelay: removePendingRelay2, markPendingRelayErrored: markPendingRelayErrored2, jobIdToHex: jobIdToHex2 };
  }, true ? __vite__mapDeps([0,1,2]) : void 0);
  const job = await submitRelayJob(serializedTx, walletPublicKey, signTransaction, submitOpts);
  const jobIdHex = jobIdToHex(job.jobId);
  console.log("[Relay] Monitoring job:", job.jobAddress.toBase58().slice(0, 12) + "...");
  let result;
  try {
    result = await monitorJob(job.jobAddress, timeoutMs, innerBlockhash);
  } catch (e) {
    if (e instanceof InnerBlockhashExpiredError) {
      e.failedOperator = job.selectedOperator;
      try {
        await cancelRelayJob(job.jobAddress, job.ephemeralKeypair);
        await removePendingRelay(jobIdHex);
        console.log("[Relay] cancelled stale job after blockhash expiry (failed op=" + job.selectedOperator.toBase58().slice(0, 8) + "...)");
      } catch (cancelErr) {
        console.warn("[Relay] cancel after blockhash expiry failed: " + cancelErr.message);
        await markPendingRelayErrored(jobIdHex, `blockhash-expired-cancel-failed: ${(cancelErr == null ? void 0 : cancelErr.message) ?? String(cancelErr)}`);
      }
    } else {
      await markPendingRelayErrored(jobIdHex, `monitor threw: ${(e == null ? void 0 : e.message) ?? String(e)}`);
    }
    throw e;
  }
  if (!result.success) {
    const statusNames = ["Pending", "Completed", "Expired", "Cancelled"];
    const status = statusNames[result.status] || String(result.status);
    await markPendingRelayErrored(jobIdHex, `status=${status}`);
    throw new Error(`Relay job failed with status: ${status}`);
  }
  await removePendingRelay(jobIdHex);
  console.log("[Relay] Job completed successfully");
  return job.signature;
}
export {
  InnerBlockhashExpiredError,
  JobStatus,
  MAX_CHUNK_DATA_SIZE,
  RELAYER_PROGRAM_ID,
  cancelRelayJob,
  encryptForRelayer,
  fetchActiveRelayers,
  fetchRelayerConfig,
  filterByLiveness,
  generateJobId,
  monitorJob,
  relayTransaction,
  selectRelayer,
  submitChunkedRelayJob,
  submitRelayJob
};
