const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/relay-hCgD2HqU.js","assets/popup.html-BW_QXm9R.js","assets/storage-D0jtF-fq.js","assets/popup-CQFzN3x4.css"])))=>i.map(i=>d[i]);
import { P as PublicKey, q as TransactionMessage, V as VersionedTransaction, _ as __vitePreload } from "./popup.html-BW_QXm9R.js";
import "./storage-D0jtF-fq.js";
const V3_RELAYER_TIMEOUT_MS = 18e4;
const V3_STATIC_LUT = new PublicKey("J8zM2zwmx8zNMkWeej55P59EWsy9Rz6zgxxA2uCX4pTm");
let cachedLut = null;
async function getLutAccount(connection) {
  if (cachedLut) return cachedLut;
  const res = await connection.getAddressLookupTable(V3_STATIC_LUT);
  if (!res.value) throw new Error(`V3 static LUT ${V3_STATIC_LUT.toBase58()} not found on-chain`);
  cachedLut = res.value;
  return cachedLut;
}
class OversizedInnerTxError extends Error {
  constructor(innerTxBytes, budgetBytes) {
    super(
      `Inner tx (${innerTxBytes}B) exceeds v1 relay envelope budget (${budgetBytes}B)`
    );
    this.innerTxBytes = innerTxBytes;
    this.budgetBytes = budgetBytes;
    this.name = "OversizedInnerTxError";
  }
}
async function signAndSendViaRelayer(connection, tx, keypair, walletSigner) {
  var _a;
  const t0 = Date.now();
  console.log("[V3-Relay] Step 1: signAndSendViaRelayer entry, ix count=" + tx.instructions.length);
  if (!keypair && !walletSigner) {
    throw new Error("signAndSendViaRelayer: no signer (keypair or walletSigner) provided");
  }
  const userPubkey = keypair ? keypair.publicKey : walletSigner.publicKey;
  console.log("[V3-Relay] Step 2: signer = " + userPubkey.toBase58().slice(0, 8) + "... (kind=" + (keypair ? "keypair" : "walletSigner") + ")");
  const { blockhash } = await connection.getLatestBlockhash("confirmed");
  const useVersioned = keypair !== null;
  let innerBytes;
  if (useVersioned) {
    const lut = await getLutAccount(connection);
    console.log("[V3-Relay] Step 3 (v0): using LUT " + V3_STATIC_LUT.toBase58().slice(0, 8) + "... (" + lut.state.addresses.length + " static accounts)");
    const message = new TransactionMessage({
      payerKey: userPubkey,
      recentBlockhash: blockhash,
      instructions: tx.instructions
    }).compileToV0Message([lut]);
    const versionedTx = new VersionedTransaction(message);
    versionedTx.sign([keypair]);
    innerBytes = versionedTx.serialize();
  } else {
    tx.recentBlockhash = blockhash;
    tx.feePayer = userPubkey;
    console.log("[V3-Relay] Step 3 (legacy): walletSigner path, no LUT compression");
    const signed = await walletSigner.signTransaction(tx);
    innerBytes = signed.serialize();
  }
  const budget = inferV1InnerTxBudget();
  console.log("[V3-Relay] Step 4: inner tx signed, size=" + innerBytes.length + "B (v1 budget=" + budget + "B" + (useVersioned ? ", v0+LUT" : ", legacy") + ")");
  const useChunked = innerBytes.length > budget;
  if (useChunked) {
    console.log("[V3-Relay] PREFLIGHT: " + innerBytes.length + "B > " + budget + "B → routing chunked");
  }
  const signFn = async (fundTx) => {
    console.log("[V3-Relay] Step 5: signing fund tx (main → ephemeral pre-fund)");
    if (keypair) {
      fundTx.sign(keypair);
      return fundTx;
    }
    return walletSigner.signTransaction(fundTx);
  };
  console.log("[V3-Relay] Step 6: calling relayTransaction (path=" + (useChunked ? "chunked" : "legacy") + ", timeout=" + V3_RELAYER_TIMEOUT_MS + "ms)");
  const {
    relayTransaction,
    InnerBlockhashExpiredError,
    fetchActiveRelayers,
    submitChunkedRelayJob,
    monitorJob,
    cancelRelayJob
  } = await __vitePreload(async () => {
    const {
      relayTransaction: relayTransaction2,
      InnerBlockhashExpiredError: InnerBlockhashExpiredError2,
      fetchActiveRelayers: fetchActiveRelayers2,
      submitChunkedRelayJob: submitChunkedRelayJob2,
      monitorJob: monitorJob2,
      cancelRelayJob: cancelRelayJob2
    } = await import("./relay-hCgD2HqU.js");
    return {
      relayTransaction: relayTransaction2,
      InnerBlockhashExpiredError: InnerBlockhashExpiredError2,
      fetchActiveRelayers: fetchActiveRelayers2,
      submitChunkedRelayJob: submitChunkedRelayJob2,
      monitorJob: monitorJob2,
      cancelRelayJob: cancelRelayJob2
    };
  }, true ? __vite__mapDeps([0,1,2,3]) : void 0);
  const activeRelayers = await fetchActiveRelayers(connection);
  const maxAttempts = Math.max(1, activeRelayers.length);
  const excludedOperators = /* @__PURE__ */ new Set();
  console.log(`[V3-Relay] Step 6: ${activeRelayers.length} active relayers on-chain, maxAttempts=${maxAttempts}`);
  activeRelayers.forEach((r, i) => {
    const ageSlots = r.lastActiveSlot;
    console.log(`[V3-Relay]   relayer ${i}: op=${r.operator.toBase58().slice(0, 8)}… stake=${(r.stake / 1e9).toFixed(2)} SOL last_active_slot=${ageSlots} active=${r.isActive}`);
  });
  const reSign = async (bh) => {
    if (useVersioned) {
      const lut = await getLutAccount(connection);
      const message = new TransactionMessage({
        payerKey: userPubkey,
        recentBlockhash: bh,
        instructions: tx.instructions
      }).compileToV0Message([lut]);
      const versionedTx = new VersionedTransaction(message);
      versionedTx.sign([keypair]);
      return versionedTx.serialize();
    }
    tx.recentBlockhash = bh;
    tx.signatures = [];
    const signed = await walletSigner.signTransaction(tx);
    return signed.serialize();
  };
  const callRelayLegacy = async (innerSerialized, innerBh) => relayTransaction(innerSerialized, userPubkey, signFn, {
    forceV1Encryption: true,
    timeoutMs: V3_RELAYER_TIMEOUT_MS,
    innerBlockhash: innerBh,
    excludedOperators: excludedOperators.size > 0 ? excludedOperators : void 0
  });
  const callRelayChunked = async (innerSerialized, innerBh) => {
    const job = await submitChunkedRelayJob(innerSerialized, userPubkey, signFn, {
      forceV1Encryption: false,
      // chunked unlocks v2 hybrid by default
      excludedOperators: excludedOperators.size > 0 ? excludedOperators : void 0
    });
    try {
      const result = await monitorJob(job.jobAddress, V3_RELAYER_TIMEOUT_MS, innerBh);
      if (!result.success) {
        throw new Error(`Chunked relay job failed with status ${result.status}`);
      }
      return job.signature;
    } catch (e) {
      if (e instanceof InnerBlockhashExpiredError) {
        e.failedOperator = job.selectedOperator;
        try {
          await cancelRelayJob(job.jobAddress, job.ephemeralKeypair);
        } catch (cancelErr) {
          console.warn("[V3-Relay] cancel chunked job after expiry failed: " + cancelErr.message);
        }
      }
      throw e;
    }
  };
  const callRelay = (innerSerialized, innerBh) => useChunked ? callRelayChunked(innerSerialized, innerBh) : callRelayLegacy(innerSerialized, innerBh);
  let currentBytes = innerBytes;
  let currentBh = blockhash;
  let lastError;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      const sig = await callRelay(currentBytes, currentBh);
      console.log("[V3-Relay] Step 7: DONE in " + (Date.now() - t0) + "ms (attempt " + attempt + "/" + maxAttempts + "), outer sig=" + sig.slice(0, 12) + "...");
      return sig;
    } catch (e) {
      lastError = e;
      if (!(e instanceof InnerBlockhashExpiredError)) {
        throw e;
      }
      const failedOp = (_a = e.failedOperator) == null ? void 0 : _a.toBase58();
      if (failedOp) excludedOperators.add(failedOp);
      console.log("[V3-Relay] attempt " + attempt + "/" + maxAttempts + " timed out (op=" + ((failedOp == null ? void 0 : failedOp.slice(0, 8)) ?? "?") + ") — excluding + retrying");
      if (attempt === maxAttempts) {
        console.warn("[V3-Relay] all " + maxAttempts + " relayers exhausted — failing closed");
        const exhausted = new Error(
          `All ${maxAttempts} active relayers timed out — privacy path unavailable. Excluded: ${Array.from(excludedOperators).map((o) => o.slice(0, 8)).join(", ")}`
        );
        exhausted.code = "RELAYERS_EXHAUSTED";
        throw exhausted;
      }
      currentBh = (await connection.getLatestBlockhash("confirmed")).blockhash;
      currentBytes = await reSign(currentBh);
    }
  }
  throw lastError ?? new Error("relayTransaction loop exited unexpectedly");
}
function inferV1InnerTxBudget() {
  const SOLANA_TX_CAP = 1232;
  const OUTER_SUBMIT_JOB_FIXED = 270;
  const IX_DATA_FIXED = 44;
  const V1_ENCRYPT_OVERHEAD = 73;
  return SOLANA_TX_CAP - OUTER_SUBMIT_JOB_FIXED - IX_DATA_FIXED - V1_ENCRYPT_OVERHEAD;
}
export {
  OversizedInnerTxError,
  inferV1InnerTxBudget,
  signAndSendViaRelayer
};
