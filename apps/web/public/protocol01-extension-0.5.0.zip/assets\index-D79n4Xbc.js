import { T as TOKEN_PROGRAM_ID, r as addSigners, j as TokenInstruction, p as TransactionInstruction, E as struct, G as u8 } from "./popup.html-BW_QXm9R.js";
import { A, a, b, c, d, e, M, f, g, h, i, k, l, m, n, s, t, u, v, w, F, H } from "./popup.html-BW_QXm9R.js";
import "./storage-D0jtF-fq.js";
const closeAccountInstructionData = struct([u8("instruction")]);
function createCloseAccountInstruction(account, destination, authority, multiSigners = [], programId = TOKEN_PROGRAM_ID) {
  const keys = addSigners([
    { pubkey: account, isSigner: false, isWritable: true },
    { pubkey: destination, isSigner: false, isWritable: true }
  ], authority, multiSigners);
  const data = Buffer.alloc(closeAccountInstructionData.span);
  closeAccountInstructionData.encode({ instruction: TokenInstruction.CloseAccount }, data);
  return new TransactionInstruction({ keys, programId, data });
}
export {
  A as ACCOUNT_SIZE,
  a as ACCOUNT_TYPE_SIZE,
  b as ASSOCIATED_TOKEN_PROGRAM_ID,
  c as AccountLayout,
  d as AccountState,
  e as AccountType,
  M as MULTISIG_SIZE,
  f as MintLayout,
  g as MultisigLayout,
  TOKEN_PROGRAM_ID,
  h as TokenAccountNotFoundError,
  i as TokenError,
  TokenInstruction,
  k as TokenInvalidAccountError,
  l as TokenInvalidAccountOwnerError,
  m as TokenInvalidAccountSizeError,
  n as TokenOwnerOffCurveError,
  closeAccountInstructionData,
  s as createAssociatedTokenAccountIdempotentInstruction,
  t as createAssociatedTokenAccountInstruction,
  createCloseAccountInstruction,
  u as createTransferInstruction,
  v as getAccount,
  w as getAssociatedTokenAddress,
  F as transferInstructionData,
  H as unpackAccount
};
