import { w } from "./core-Bv147VFl.js";
import "./popup.html-DEux-n4G.js";
import "./storage-DPMBpVzN.js";
const chevronRightSvg = w`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M4.96 14.54a1 1 0 0 1 0-1.41L10.09 8 4.96 2.87a1 1 0 0 1 1.41-1.41l5.84 5.83a1 1 0 0 1 0 1.42l-5.84 5.83a1 1 0 0 1-1.41 0Z"
    clip-rule="evenodd"
  />
</svg>`;
export {
  chevronRightSvg
};
