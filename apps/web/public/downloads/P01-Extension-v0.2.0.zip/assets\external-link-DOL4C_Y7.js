import { w } from "./core-CJAaE_nG.js";
import "./popup.html-V4e6hTmc.js";
import "./storage-DPMBpVzN.js";
const externalLinkSvg = w`<svg fill="none" viewBox="0 0 14 15">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M3.74 3.99a1 1 0 0 1 1-1H11a1 1 0 0 1 1 1v6.26a1 1 0 0 1-2 0V6.4l-6.3 6.3a1 1 0 0 1-1.4-1.42l6.29-6.3H4.74a1 1 0 0 1-1-1Z"
    clip-rule="evenodd"
  />
</svg>`;
export {
  externalLinkSvg
};
